# 2.Write a function in python in python, which will return maximum i.e function
# should return dictionary like
# {
# “3” : 70
# }

def maxvaluedict(self, **kwargs):
    max_value = max(dict.values())  # maximum value
    max_keys = [k for k, v in dict.items() if v == max_value]  # getting all keys containing the `maximum`
    print(max_keys, max_value)


dict = {"1": 60, "2": 20, "3": 30, "4": 70, "5": 40, "6": 90, "7": 80, }
maxvaluedict(dict)

