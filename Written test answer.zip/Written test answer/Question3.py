# Assume we have list like this
# [0,0,0,1,1,1,0,0,0,1,1,0,1,1,1,1,0,0,1,1]
# Basically a list of zero’s and one’s.
# Write a python function to the number of maximum consecutive one’s present in
# the array.
# E.g output for the above array would be 4

def getMaxConsone(arr, n):
    count = 0
    result = 0
    for i in range(0, n):
        # Reset count when 0 is found
        if (arr[i] == 0):
            count = 0  # If 1 is found, increment count and update result if count becomes more
        else:
            # increase count
            count += 1
            result = max(result, count)
    return result


arr = [0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1]
n = len(arr)
print(getMaxConsone(arr, n))
