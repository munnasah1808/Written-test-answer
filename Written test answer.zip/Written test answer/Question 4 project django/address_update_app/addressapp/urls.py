from django.urls import path
from .views.home import index
from .views.signup import Signup
from .views.login import Login, logout
from .views.crud import  addressview, add, update, delete


urlpatterns = [
    path('', index, name='homepage'),
    path('signup', Signup.as_view(),name='signup'),
    path('login', Login.as_view(),name='login'),
    path('logout', logout,name='logout'),
    path('addressview', addressview,name="addressview"),
    path('add', add,name="add_address"),
    path('update/<int:pk>/', update,name="update_address"),
    path('delete/<int:pk>/', delete, name="delete_address"),
    
]
