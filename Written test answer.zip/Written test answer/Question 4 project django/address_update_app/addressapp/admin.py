from django.contrib import admin
from .models.address import Address
from .models.user import User



class AdminAddress(admin.ModelAdmin):
    list_display = ['street', 'pincode', 'country', 'state', 'phone_number']



class AdminUser(admin.ModelAdmin):
    list_display = ['username','first_name', 'last_name', 'phone_number', 'email', 'password']



# Register your models here.
admin.site.register(Address, AdminAddress)
admin.site.register(User, AdminUser)
