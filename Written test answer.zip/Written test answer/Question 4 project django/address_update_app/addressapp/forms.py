from django import forms
from addressapp.models.address import Address
from addressapp.models.user import User


# ProductForm 
class AddressForm(forms.ModelForm):
    class Meta:
        model = Address
        fields = ['id','street','pincode','country','state','phone_number']
        widgets = {
            'street' : forms.TextInput(attrs={'class':'form-control'}),
            'pincode' : forms.TextInput(attrs={'class':'form-control'}),
            'country' : forms.TextInput(attrs={'class':'form-control'}),
            'state' : forms.TextInput(attrs={'class':'form-control'}),
            'phone_number' : forms.TextInput(attrs={'class':'form-control'}),
            
        }


