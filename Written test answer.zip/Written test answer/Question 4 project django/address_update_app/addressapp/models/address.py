from django.db import models


# Address Model
class Address(models.Model):
    street = models.CharField(max_length=200,blank=True)
    pincode = models.CharField(max_length=6, default="437015")
    country = models.CharField(max_length=64,blank=True)
    state = models.CharField(max_length=64, default='Mumbai',blank=True)
    phone_number = models.CharField(max_length=20)
