from django.shortcuts import render, HttpResponseRedirect
from addressapp.models.address import Address


# Create your views here.
def index(request):
    address = Address.objects.all()
    return render(request,'index.html',{'address':address})



