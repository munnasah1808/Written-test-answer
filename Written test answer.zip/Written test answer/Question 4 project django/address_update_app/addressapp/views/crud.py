from django.shortcuts import render, redirect, get_object_or_404, HttpResponseRedirect
from addressapp.models.address import Address
from addressapp.forms import AddressForm
from addressapp.models.user import User
#from django.contrib.auth.decorators import login_required


#@login_required(login_url='login')
def addressview(request):
        address = Address.objects.all()
        context = {'address':address}
        return render(request,'addresscrud.html',context)



# Add Address Function Based View
def add(request):
    form = AddressForm(request.POST)
    if form.is_valid():
        form.save()
        return redirect('addressview')
    return render(request, 'addadress.html',{'form':form})

     
# Update Address Function Based View
def update(request, pk):
    items= get_object_or_404(Address, pk=pk)
    form = AddressForm(request.POST or None, instance=items)
    if form.is_valid():
        form.save(commit=True)
        return redirect('addressview')
    return render(request,'update_address.html', {'form':form})



# Delete Address Function Based View
def delete(request,pk):
    if request.method == 'POST':
        pi = Address.objects.get(pk=pk)
        pi.delete()
        return redirect('addressview')

