from django.shortcuts import render, redirect, HttpResponseRedirect
from django.contrib.auth.hashers import check_password
from addressapp.models.user import User
from django.views import View


class Login(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = User.get_user_by_username(username)
        print(username, password)
        error_message = None
        if user:
            flag = check_password(password, user.password)
            if flag:
                request.session['user'] = user.id
                return redirect('homepage')
            else:
                error_message = 'Email or Password Invalid!!!'
        else:
            error_message = 'Email or Password Invalid!!'
        return render(request, 'login.html', {'error': error_message})



def logout(request):
    request.session.clear()
    return redirect('login')

