from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from addressapp.models.user import User
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        username = postData.get('username')
        first_name = postData.get('first name')
        last_name = postData.get('last name')
        phone_number = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')
        # validation
        value = {
            'username' : username,
            'first_name': first_name,
            'last_name': last_name,
            'phone_number': phone_number,
            'email': email
        }

        user = User( username=username,
                     first_name=first_name,
                     last_name=last_name,
                     phone_number=phone_number,
                     email=email,
                     password=password)
        error_message = self.validateUser(user)

        # saving
        if not error_message:
            print(username, first_name, last_name, phone_number, email, password)
            user.password = make_password(user.password)
            user.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }

            return render(request, 'signup.html', data)

    def validateUser(self, user):
        error_message = None
        if (not user.username):
            error_message = "User Name Required !!!"
        elif len(user.username) < 4:
            error_message = 'User Name must be 4 char long or more'
        elif (not user.first_name):
            error_message = "First Name Required !!!"
        elif len(user.first_name) < 4:
            error_message = 'First Name must be 4 char long or more'
        elif not user.last_name:
            error_message = 'Last Name Required'
        elif not user.phone_number:
            error_message = 'Phone Number required'
        elif len(user.phone_number) < 10:
            error_message = 'Phone Number must be 10 char Long'
        elif len(user.password) < 6:
            error_message = 'Password must be 6 char long'
        elif len(user.email) < 5:
            error_message = 'Email must be 5 char long'
        elif user.isExists():
            error_message = 'Email Address Already Registered..'
        # saving

        return error_message
