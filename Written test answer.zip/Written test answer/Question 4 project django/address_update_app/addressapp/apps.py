from django.apps import AppConfig


class AddressappConfig(AppConfig):
    name = 'addressapp'
