# 1.Use python lists and make an list of numbers.
# Write a function which returns sum of the list of numbers

def sum_of_list(list):
    sum = 0
    for num in list:
        sum += int(num)
    print("Calculating sum of element of input list:", sum)


# Taking input from the user
input_string = input("Enter a list element separated by space: ")
list = input_string.split()
# function call
sum_of_list((list))
